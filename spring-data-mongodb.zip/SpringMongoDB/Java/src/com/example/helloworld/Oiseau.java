package com.example.helloworld;

public class Oiseau extends Animal {

    void deplacer() {
        System.out.println("Je vole");
    }
}
