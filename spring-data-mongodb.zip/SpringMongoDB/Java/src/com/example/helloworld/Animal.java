package com.example.helloworld;

public class Animal {

    void deplacer() {
        System.out.println("Je me deplace");
    }
}
