package com.example.helloworld;

import java.util.*;

public class Test {

    public static void main(String[] args) {


//        Map<String, Integer> myMap = new HashMap<String, Integer>();
//        myMap.put("Jenny", 34);
//        myMap.put("Livia", 28);
//        myMap.put("Paul", 31);
//        System.out.println(myMap.get("Jenny"));
//        Set<String> ingredients = new HashSet<String>();
//        List<Integer> myList =  new ArrayList<Integer>();
//        myList.add(7);
//        myList.add(5);
//        myList.add(1, 12);
//        myList.set(0,4);
//        myList.remove(1);
//
//        System.out.println(myList);
//        System.out.println(myList.size());
//        Animal a1 = new Animal();
//        Animal a2 = new Chien();
//        Animal a3 = new Oiseau();
//
//        a1.deplacer();
//        a2.deplacer();
//        a3.deplacer();
//        FigureGeo figure = new FigureGeo();
//        figure.moveTo(1,1);
//        Carre carre = new Carre();
//        carre.moveTo(2, 2);
    }
}
