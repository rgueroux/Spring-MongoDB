package com.example.helloworld;

public class Chien extends Animal {

    void deplacer() {
        System.out.println("Je marche");
    }
}
