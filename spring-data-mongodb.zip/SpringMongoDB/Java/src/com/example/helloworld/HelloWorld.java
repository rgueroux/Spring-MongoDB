package com.example.helloworld;

public class HelloWorld {
    public static void main(String[] args) {

        Book myBook = new Book("Coding is art", "Becky James", 425);

        System.out.println(myBook.author);

//        int x = 10;
//
//        x += 12;
//
//        final int y = x/4;
//
//        x = x + y;
//        System.out.println(x + "gdf" + y);
//        String[] basket = new String[]{"apple", "Orange", "Banana"};
//
//        for (String iteration: basket){
//            if (iteration == "Orange"){
//                System.out.println("J'ai un(e): " + iteration);
//                break;
//            }
//        }
//        int numberOfTrees = 0;
//
//        while (numberOfTrees < 10){
//            numberOfTrees += 1;
//            System.out.println("I planted this number of tree" + numberOfTrees);
//        }
//
//        System.out.println("I have a forest");

//        int[] myArray = new int[]{7,2,4,5};
//
//        for (int iteration: myArray) {
//            System.out.println(iteration);
//        }

//        for (int i=0; i<myArray.length;i++) {
//
//            System.out.println(myArray[i]);
//        }
//        sayHello("World");

//    /**
//     * YOLO
//     * @param recipient
//     */
//    private static void sayHello(String recipient) {
//        System.out.println("Hello " + recipient);

//        String firstFavoriteCity = "New York";11
//        String secondFavouriteCity = "Buenos Aires";
//        String favourites = "My favourites cities are " + firstFavoriteCity + " and " + secondFavouriteCity;
//
//        System.out.println(favourites);
//        String text = "A wonderful string that consist of multiple characters";
//        int numberOfVowels = 0;
//        double percentageOfVowels = 0.0;
//
//        final int numberOfWeekDays = 7;
//        final String myFavouriteFood = "Icecream";
//
//        int numberOfPets = 1;
//        String currentSeason = "Winter";


//        numberOfWeekDays = numberOfWeekDays + 1;
//        myFavouriteFood = "Cake";

//        numberOfPets = 3;
//        currentSeason = "Summer";
//
//        System.out.println(numberOfWeekDays);
//        System.out.println(myFavouriteFood);
//        System.out.println(numberOfPets);
//        System.out.println(currentSeason);
//
//        int ongoingAllowance = 500;
//        int savings = 1000;
//        int bonusAllowance = 500;
//
//        savings = savings + 100;
//        ongoingAllowance = ongoingAllowance - 50;
//
//        int numberOfDaysToSAve = (5000 - ongoingAllowance) / 500;
//        ongoingAllowance = ongoingAllowance + (30 - 10) * 7;
//
//        System.out.println("You have an ongoing allowance of" + ongoingAllowance + "You have a savings" + savings + "You have an ongoing bonus allowance of" + bonusAllowance);
//        System.out.println(numberOfDaysToSAve);
    }
}
