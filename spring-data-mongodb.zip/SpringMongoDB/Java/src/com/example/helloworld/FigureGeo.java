package com.example.helloworld;

public class FigureGeo {

    private int x;
    private int y;

    public void moveTo(int newX, int newY) {
        this.x = newX;
        this.y = newY;
    }
}
