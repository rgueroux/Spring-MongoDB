package com.example.helloworld;

public class Book {

    String title;
    String author;
    int numberOfPages;
    String publisher;

    public Book(String title, String author, int numberOfPages) {
        this.title = title;
        this.author = author;
        this.numberOfPages = numberOfPages;
    }
}
